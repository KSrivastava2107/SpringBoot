package com.Rest.SpringRest.Restful.Controller;

import com.Rest.SpringRest.Restful.Entity.entitydemo;
import com.Rest.SpringRest.Restful.Service.servicedemo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/entities")
public class MyController {

    private final servicedemo serdemo;

    @Autowired
    public MyController(servicedemo serdemo) {
        this.serdemo = serdemo;
    }

    @GetMapping
    public ResponseEntity<List<entitydemo>> getAllEntities() {
        return ResponseEntity.ok(serdemo.getAllEntities());
    }

    @GetMapping("/{id}")
    public ResponseEntity<entitydemo> getEntityById(@PathVariable Long id) {
        return ResponseEntity.ok(serdemo.getEntityById(id));
    }

    @PostMapping
    public ResponseEntity<entitydemo> createEntity(@RequestBody entitydemo demo) {
        return ResponseEntity.ok(serdemo.saveEntity(demo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<entitydemo> updateEntity(@PathVariable Long id, @RequestBody entitydemo demo) {
        entitydemo existing=serdemo.getEntityById(id);
        existing.setName(demo.getName());
        existing.setPrice(demo.getPrice());

        entitydemo updated=serdemo.saveEntity(existing);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEntity(@PathVariable Long id) {
        serdemo.deleteEntity(id);
        return ResponseEntity.noContent().build();
    }
}
