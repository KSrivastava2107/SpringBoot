package com.Rest.SpringRest.Restful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulApplicationTests {

	@Test
	void contextLoads() {
	}

}
