# ATM-Simulator
Kind of ATM that does all the work that an ATM can do and it can create a new account of user also. User can deposit money after making new account.
