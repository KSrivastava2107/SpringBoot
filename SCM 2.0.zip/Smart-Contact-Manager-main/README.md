# Smart-Contact-Manager
In this project I have used Spring Boot for backend and HTML and CSS for frontend.
This is basically a smart contact manager in which user creates an account and can add many contacts in their own accout.
Every user have their contact list which can be viewed by the user only.
User can add, delete and update contacts.
