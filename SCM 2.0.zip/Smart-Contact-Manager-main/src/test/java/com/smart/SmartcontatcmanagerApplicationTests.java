package com.smart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartcontatcmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
